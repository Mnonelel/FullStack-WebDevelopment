﻿
using System.ComponentModel.DataAnnotations.Schema;

namespace MMSCRUD.Models
{
    public class Visit
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid PatientId { get; set; }
        [ForeignKey("PatientId")]
        public Patient Patient { get; set; }

        public Guid DoctorId { get; set; }
        [ForeignKey("DoctorId")]
        public User Doctor { get; set; }

        public string Notes { get; set; }
        public DateTime Timestamp { get; set; }
    }
}
