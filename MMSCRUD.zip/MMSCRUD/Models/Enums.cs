﻿using System.Text.Json.Serialization;

namespace MMSCRUD.Models
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum Gender
    {
        Male,
        Female,
        Other
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum MedicalAid
    {
        No,
        Yes
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum MedicalAidCompany
    {
        None,
        Discovery,
        Bonitas,
        ProfMed,
        Momentum,
        GEMS,
        MediHelp
    }
}
