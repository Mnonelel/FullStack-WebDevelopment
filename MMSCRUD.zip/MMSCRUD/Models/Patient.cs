﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace MMSCRUD.Models
{
    public class Patient
    {
        [Key]
        public Guid Id { get; set; }

        public string Name { get; set; } = string.Empty;
        public string Surname { get; set; } = string.Empty;
        public string Username { get; set; } = string.Empty;
        public Gender Gender { get; set; }    // ✅ Dropdown
        public string HomeAddress { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public MedicalAid MedicalAid { get; set; }  // ✅ Dropdown
        public MedicalAidCompany MedicalAidCompany { get; set; }  // ✅ Dropdown
        [JsonIgnore]
        public List<Visit> Visits { get; set; }
    }
   
}





