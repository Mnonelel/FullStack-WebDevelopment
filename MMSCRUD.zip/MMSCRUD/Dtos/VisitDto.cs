﻿namespace MMSCRUD.Dtos
{
    public class VisitDto
    {
        public Guid Id { get; set; }
        public Guid PatientId { get; set; }
        public Guid DoctorId { get; set; }
        public DateTime Timestamp { get; set; }
        public string Notes { get; set; }
    }
}
