﻿using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using MMSCRUD.Models;

namespace MMSCRUD.Swagger
{
    public class MedicalAidConditionalSchemaFilter : ISchemaFilter
    {
        public void Apply(OpenApiSchema schema, SchemaFilterContext context)
        {
            if (context.Type == typeof(Patient))
            {
                // Add Swagger description explaining conditional logic
                if (schema.Properties.ContainsKey("medicalAidCompany"))
                {
                    schema.Properties["medicalAidCompany"].Description =
                        "🏥 Only required if 'MedicalAid' is 'Yes'.";
                }
            }
        }
    }
}

