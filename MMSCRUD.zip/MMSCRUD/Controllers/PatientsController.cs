﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MMSCRUD.Models;
using MMSCRUD.Data;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace MMSCRUD.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PatientController : ControllerBase
    {
        private readonly MMSDbContext _db;

        public PatientController(MMSDbContext db)
        {
            _db = db;
        }

        // GET: api/Patient?q=John
        [HttpGet]
        public async Task<IActionResult> GetAll(string? q)
        {
            var query = _db.Patients.AsQueryable();

            if (!string.IsNullOrEmpty(q))
            {
                query = query.Where(p => p.Name.Contains(q) || p.Surname.Contains(q));
            }

            var patients = await query.ToListAsync();
            return Ok(patients);
        }

        // GET: api/Patient/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var patient = await _db.Patients.FindAsync(id);
            if (patient == null) return NotFound();
            return Ok(patient);
        }

        // POST: api/Patient
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Patient patient)
        {
            if (patient == null) return BadRequest();

            patient.Id = Guid.NewGuid(); // Ensure a new Guid
            _db.Patients.Add(patient);
            await _db.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = patient.Id }, patient);
        }

        // PUT: api/Patient/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, [FromBody] Patient updatedPatient)
        {
            var patient = await _db.Patients.FindAsync(id);
            if (patient == null) return NotFound();

            patient.Name = updatedPatient.Name;
            patient.Surname = updatedPatient.Surname;

            await _db.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/Patient/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var patient = await _db.Patients.FindAsync(id);
            if (patient == null) return NotFound();

            _db.Patients.Remove(patient);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
