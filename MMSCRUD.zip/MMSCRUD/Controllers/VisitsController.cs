﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MMSCRUD.Models;
using MMSCRUD.Data;
using System;
using System.Threading.Tasks;

namespace MMSCRUD.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VisitController : ControllerBase
    {
        private readonly MMSDbContext _db;

        public VisitController(MMSDbContext db)
        {
            _db = db;
        }

        // DTO for creating a visit
        public class CreateVisitDto
        {
            public Guid PatientId { get; set; }
            public Guid DoctorId { get; set; } // optional, 0 = use logged-in user
            public string Notes { get; set; }
        }

        // POST: api/Visit
        [HttpPost]
        public async Task<IActionResult> CreateVisit([FromBody] CreateVisitDto dto)
        {
            // Validate Patient exists
            var patient = await _db.Patients.FindAsync(dto.PatientId);
            if (patient == null)
                return NotFound($"Patient with ID {dto.PatientId} not found.");

            // Determine Doctor ID (use logged-in user if not specified)
            Guid loggedInUserId = Guid.Parse("YOUR-LOGGED-IN-USER-GUID"); // replace with actual
            Guid doctorId = dto.DoctorId == Guid.Empty ? loggedInUserId : dto.DoctorId;

            var doctor = await _db.Users.FindAsync(doctorId);
            if (doctor == null)
                return NotFound($"Doctor with ID {doctorId} not found.");

            // Create Visit
            var visit = new Visit
            {
                PatientId = dto.PatientId,
                DoctorId = doctorId,
                Notes = dto.Notes,
                Timestamp = DateTime.UtcNow
            };

            _db.Visits.Add(visit);
            await _db.SaveChangesAsync();

            // Return the created visit
            return Ok(visit);
        }

        // GET: api/Visit
        [HttpGet]
        public async Task<IActionResult> GetVisits()
        {
            var visits = await _db.Visits
                .Include(v => v.Patient)
                .Include(v => v.Doctor)
                .ToListAsync();
            return Ok(visits);
        }

        // GET: api/Visit/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetVisit(int id)
        {
            var visit = await _db.Visits
                .Include(v => v.Patient)
                .Include(v => v.Doctor)
                .FirstOrDefaultAsync(v => v.Id == Guid.Empty);

            if (visit == null) return NotFound();

            return Ok(visit);
        }
    }
}


