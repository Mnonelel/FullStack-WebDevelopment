﻿window.onload = function () {
    // Wait for Swagger UI to load
    const observer = new MutationObserver(() => {
        // Gender dropdown
        document.querySelectorAll('input[placeholder="gender"]').forEach(input => {
            if (!input.dataset.replaced) {
                const select = document.createElement("select");
                ["Male", "Female", "Other"].forEach(gender => {
                    const option = document.createElement("option");
                    option.value = gender;
                    option.textContent = gender;
                    select.appendChild(option);
                });
                select.onchange = () => input.value = select.value;
                input.style.display = "none";
                input.parentNode.insertBefore(select, input);
                input.dataset.replaced = true;
            }
        });

        // Medical Aid dropdown
        document.querySelectorAll('input[placeholder="medicalAidCompany"]').forEach(input => {
            if (!input.dataset.replaced) {
                const select = document.createElement("select");
                ["ProfMed", "Discovery", "Momentum", "Bonitas", "None"].forEach(company => {
                    const option = document.createElement("option");
                    option.value = company;
                    option.textContent = company;
                    select.appendChild(option);
                });
                select.onchange = () => input.value = select.value;
                input.style.display = "none";
                input.parentNode.insertBefore(select, input);
                input.dataset.replaced = true;
            }
        });
    });

    observer.observe(document.body, { childList: true, subtree: true });
};
